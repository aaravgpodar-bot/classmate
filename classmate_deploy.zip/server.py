import json
import os
import urllib.error
import urllib.request
from pathlib import Path

from flask import Flask, jsonify, request, send_from_directory


BASE_DIR = Path(__file__).resolve().parent
PUBLIC_FILES = {
    "app.js",
    "index.html",
    "manifest.json",
    "service-worker.js",
    "styles.css",
}

app = Flask(__name__, static_folder=str(BASE_DIR), static_url_path="")


@app.get("/")
def index():
    return send_from_directory(BASE_DIR, "index.html")


@app.get("/health")
def health():
    return jsonify({"status": "ok", "app": "ClassMate"})


@app.post("/api/generate-game")
def generate_game():
    body = request.get_json(silent=True) or {}
    subject = str(body.get("subject", "")).strip()[:80] or "General Knowledge"
    try:
        questions = ai_game_questions(subject)
    except RuntimeError as error:
        return jsonify({"error": str(error)}), 503
    return jsonify({"subject": subject, "source": "openai", "questions": questions})


@app.get("/<path:filename>")
def static_files(filename):
    if filename not in PUBLIC_FILES:
        return jsonify({"error": "not found"}), 404
    return send_from_directory(BASE_DIR, filename)


def ai_game_questions(subject):
    api_key = os.environ.get("OPENAI_API_KEY")
    if not api_key:
        raise RuntimeError("OPENAI_API_KEY is required for AI game generation.")

    prompt = (
        "Create exactly 10 fun, school-safe rounds for a student learning game. "
        f"Subject: {subject}. "
        "Use a varied mix of modes: multiple_choice, true_false, type_answer, and best_move. "
        "Return only JSON with this shape: "
        '{"questions":[{"mode":"multiple_choice|true_false|type_answer|best_move","type":"string","q":"string","answer":"string","options":["string","string","string","string"]}]}. '
        "Rules: multiple_choice and best_move need exactly four options; true_false needs options ['True','False']; "
        "type_answer should have an empty options array and a short answer. "
        "The answer must be copied exactly into options whenever options are used. "
        "Make the round labels playful and make the modes feel different."
    )
    payload = {
        "model": os.environ.get("OPENAI_MODEL", "gpt-4o-mini"),
        "messages": [
            {"role": "system", "content": "You are ClassMate, a playful educational game question generator."},
            {"role": "user", "content": prompt},
        ],
        "response_format": {"type": "json_object"},
        "temperature": 0.9,
    }
    req = urllib.request.Request(
        "https://api.openai.com/v1/chat/completions",
        data=json.dumps(payload).encode("utf-8"),
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=30) as response:
            data = json.loads(response.read().decode("utf-8"))
        content = data["choices"][0]["message"]["content"]
        parsed = json.loads(content)
        return normalize_questions(parsed.get("questions", []), subject)
    except (KeyError, ValueError, urllib.error.URLError, urllib.error.HTTPError):
        raise RuntimeError("OpenAI game generation failed.")


def normalize_questions(raw_questions, subject):
    questions = []
    for index, item in enumerate(raw_questions[:10]):
        answer = str(item.get("answer", "")).strip()
        mode = str(item.get("mode", "multiple_choice")).strip()
        if mode not in {"multiple_choice", "true_false", "type_answer", "best_move"}:
            mode = "multiple_choice"
        options = [str(option).strip() for option in item.get("options", []) if str(option).strip()]
        if mode == "type_answer":
            options = []
        elif mode == "true_false":
            options = ["True", "False"]
            if answer.lower() not in {"true", "false"}:
                answer = "True"
        else:
            if answer and answer not in options:
                options.append(answer)
            options = options[:4]
            while len(options) < 4:
                options.append(f"{subject} clue {len(options) + 1}")
        questions.append({
            "id": f"ai-{index}",
            "mode": mode,
            "type": str(item.get("type", "AI Round")).strip() or "AI Round",
            "q": str(item.get("q", f"What is important in {subject}?")).strip(),
            "answer": answer or (options[0] if options else subject),
            "options": options,
        })
    if len(questions) < 10:
        raise RuntimeError("OpenAI returned too few questions.")
    return questions[:10]


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5177, debug=True)
